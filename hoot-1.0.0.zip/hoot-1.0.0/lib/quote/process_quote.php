<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"));

    if ($data) {
        $name = $data->name;
        $email = $data->email;
        $service = $data->service;

        // Customize the email recipient, subject, and message
        $to = "johnmmuthama1@gmail.com"; // Replace with your email address
        $subject = "Quote Request";
        $message = "Name: $name\nEmail: $email\nService: $service";
        $headers = "From: $email";

        // Send the email
        if (mail($to, $subject, $message, $headers)) {
            $response = [
                "success" => true,
                "message" => "Request submitted successfully. We will get back to you soon.",
            ];
        } else {
            $response = [
                "success" => false,
                "message" => "Failed to send the request. Please try again later.",
            ];
        }

        // Send a JSON response
        header("Content-Type: application/json");
        echo json_encode($response);
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Invalid data received"]);
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["error" => "Method not allowed"]);
}
?>
